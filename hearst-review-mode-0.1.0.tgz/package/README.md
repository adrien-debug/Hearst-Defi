# @hearst/review-mode

Admin product-review mode for Hearst stack. Packages the Kimi LLM facilitation prompts, SSE streaming helpers, structured JSON output schema, and Next.js route factories for the cockpit review-mode feature.

Extracted from `connect — Hearst Defi` (commit 88f15a1). Distributed as a private tarball.

---

## Installation

```bash
pnpm add file:./hearst-review-mode-0.1.0.tgz
```

---

## Prerequisites

### 1. Prisma models

Add these three models (plus one column) to your `schema.prisma`:

```prisma
model AdminChatMode {
  userId    String   @id
  mode      String   @default("normal") // "normal" | "review"
  updatedAt DateTime @updatedAt
}

model ReviewDocument {
  id          String   @id @default(cuid())
  userId      String
  chatId      String
  contentMd   String
  contentJson String?
  createdAt   DateTime @default(now())
}

model LlmRun {
  id               String   @id @default(cuid())
  agentName        String
  model            String
  status           String   // "success" | "failed" | "timeout"
  latencyMs        Int
  userId           String
  systemPromptHash String
  inputTokens      Int?
  outputTokens     Int?
  costUsd          Float?
  errorType        String?
  errorMessage     String?
  createdAt        DateTime @default(now())
}
```

Also add a `mode` column to your `CockpitMessage` model:

```prisma
model CockpitMessage {
  // ... existing fields ...
  mode String @default("normal") // "normal" | "review"
}
```

After editing, run:

```bash
pnpm db:migrate
```

### 2. Kimi client

The route factory expects an OpenAI-compatible client. With Hypercli:

```ts
// src/lib/llm/kimi.ts
import OpenAI from "openai";

export const KIMI_MODEL = "kimi-k2-6";

export const kimi = new OpenAI({
  apiKey: process.env.HYPERCLI_API_KEY,
  baseURL: process.env.HYPERCLI_BASE_URL ?? "https://api.hypercli.com/v1",
});
```

### 3. `requireAdmin`

A function that returns `{ userId: string }` for the authenticated admin or throws. Integrate with your auth provider (Privy, NextAuth, etc.).

---

## Example integration

### 5-file glue

**1. Product context** — `src/lib/product-context.ts`

```ts
import type { ProductContext } from "@hearst/review-mode";

export const productContext: ProductContext = {
  text: `Contexte produit — tu connais Acme DeFi PAR CŒUR :

Acme DeFi est une plateforme institutionnelle d'investissement DeFi : un vault USDC unique adossé à trois moteurs de rendement — cashflow du mining BTC (30-40%), base de rendement USDC / obligations tokenisées (25-60%), et BTC tactique (0-30%). Cible APY 8-15%, distributions mensuelles en USDC, ticket minimum 100k$, lock-up souple 30 jours, structure SPV, investisseurs professionnels uniquement.

Trois promesses produit qui doivent guider toute critique : Lisibilité (un investisseur comprend la stratégie en 5 min), Simulabilité (toute hypothèse de rendement est stressable dans le Scenario Lab), Auditabilité (preuve de réserves, événements on-chain, méthodologie publiée et versionnée).

Carte des pages (utilise ces routes ET ces noms de zones/composants EXACTS pour situer chaque remarque) :
- "/" — écran de connexion wallet (Privy). Pas de landing marketing.
- "/portfolio" — surface d'atterrissage après connexion. Zones : greeting, rangée de 3 KPI ("Portfolio Value" USDC, "Yield YTD" USDC, "Next Distribution"), donut d'allocation, courbe de valeur, liste de positions (colonnes Vault / Principal / Value / Target APY / Since).
- "/portfolio/[positionId]" — détail d'une position.
- "/vaults" — liste des produits. H1 "Select a product", cartes produit avec badge APY range.
- "/vaults/[id]" — détail d'un vault. Stat "Target APY range" avec badge de provenance, section régimes, barre "Continue → Deposit".
- "/vaults/[id]/invest" — formulaire de dépôt USDC. Eyebrow "Deposit".
- "/scenario-lab" — moteur de simulation. Zones : sliders hypothèses, courbe projetée p5/p50/p95, tableau de résultats, bouton "Export PDF".
- "/proof-center" — preuve de réserves. Zones : total USDC par bucket, timeline événements on-chain, adresses (vault, Manager Safe, PoR Registry), dernières distributions, statut audit.

Quand l'utilisateur désigne un élément de façon vague ("le bloc du haut", "le graphe", "le bouton"), rattache-le au nom de zone/composant ci-dessus le plus probable, mais marque ce rattachement comme une hypothèse. N'invente jamais un composant absent de cette carte.

Non-négociables produit (à ne JAMAIS contredire dans une proposition) : APY toujours affiché en fourchette (jamais un point unique) ; chaque métrique porte un badge de provenance (Live/Oracle/Attested/Estimated/Manual/Stale) ; pas de mots interdits (garantie, promesse, sans risque) ; toute projection montre ses hypothèses + mention "non garanti".`,
};
```

**2. Review document route** — `src/app/api/admin/review-document/route.ts`

```ts
import { createReviewDocumentRoute } from "@hearst/review-mode";
import { prisma } from "@/lib/db";
import { kimi, KIMI_MODEL } from "@/lib/llm/kimi";
import { requireAdmin } from "@/lib/auth/require-admin";
import { logger } from "@/lib/logger";
import { assertRateLimit, assertBodySize } from "@/lib/rate-limit";
import { productContext } from "@/lib/product-context";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const { GET, POST } = createReviewDocumentRoute({
  prisma,
  kimi,
  requireAdmin,
  logger,
  productContext,
  model: KIMI_MODEL,
  assertRateLimit,
  assertBodySize,
});
export { GET, POST };
```

**3. Review mode toggle route** — `src/app/api/admin/review-mode/route.ts`

```ts
import { createReviewModeRoute } from "@hearst/review-mode";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/auth/require-admin";
import { logger } from "@/lib/logger";
import { assertRateLimit, assertBodySize } from "@/lib/rate-limit";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const { GET, POST } = createReviewModeRoute({
  prisma,
  requireAdmin,
  logger,
  assertRateLimit,
  assertBodySize,
});
export { GET, POST };
```

**4. Prompt hashes** (for LlmRun stamping) — `src/lib/llm/prompt-hash.ts`

```ts
import { sha256Hex, buildFacilitatorPrompt, buildDocumentInstructions } from "@hearst/review-mode";
import { productContext } from "@/lib/product-context";

export const REVIEW_FACILITATOR_HASH = sha256Hex(
  buildFacilitatorPrompt({ productContext }),
);
export const REVIEW_DOCUMENT_HASH = sha256Hex(
  buildDocumentInstructions({ productContext }),
);
```

**5. SSE consumer UI** (scaffold yourself) — call `POST /api/admin/review-document?stream=1` and iterate over the stream:

```ts
import { parseSSEStream } from "@hearst/review-mode";

const res = await fetch("/api/admin/review-document?stream=1", {
  method: "POST",
});
if (!res.body) return;
const reader = res.body.getReader();
for await (const evt of parseSSEStream(reader)) {
  if (evt.type === "delta")  setPartial(p => p + evt.text);
  if (evt.type === "done")   setDocument(evt);
  if (evt.type === "error")  setError(evt.message);
}
```

---

## Configuration

All optional fields in `ReviewDocumentRouteDeps`:

| Option | Default | Description |
|---|---|---|
| `model` | `"kimi-k2-6"` | Kimi model identifier |
| `generationTimeoutMs` | `60_000` | LLM call timeout (ms) |
| `rateLimitMax` | `5` | Max requests per window |
| `rateLimitWindowMs` | `60_000` | Rate limit window (ms) |
| `maxTranscriptTokens` | `60_000` | Token budget for transcript |
| `reviewDocKeepLatest` | `20` | Documents retained per user |
| `getProductRoutes` | `undefined` | Optional route inventory supplier |
| `getSpecIndex` | `undefined` | Optional spec index supplier |

---

## Logger

The `logger` field in both `ReviewDocumentRouteDeps` and `ReviewModeRouteDeps` requires **all three methods** — `warn`, `info`, and `error`. All are mandatory; there are no optional fields.

```ts
export interface Logger {
  warn:  (msg: string, meta?: Record<string, unknown>, err?: Error) => void;
  info:  (msg: string, meta?: Record<string, unknown>) => void;
  error: (msg: string, meta?: Record<string, unknown>, err?: Error) => void;
}
```

To use a silent logger in tests or non-observable environments, provide explicit no-ops:

```ts
const silentLogger = {
  warn:  () => {},
  info:  () => {},
  error: () => {},
};
```

---

## Tests

```bash
pnpm test
```

---

## Versioning

- Package version: `0.1.0`
- Source commit: `88f15a1` (`connect — Hearst Defi`)
- Extracted: 2026-05-26
